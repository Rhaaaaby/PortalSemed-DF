<?php
require_once __DIR__ . '/../models/Noticia.php';

class NoticiaController {

    public function index() {
        $noticias = Noticia::all();
        require __DIR__ . '/../views/noticias/index.php';
    }

    public function create() {
        if ($_POST) {

            $imagem = null;

            if (!empty($_FILES['imagem']['name'])) {
                $nome = time() . "_" . $_FILES['imagem']['name'];
                move_uploaded_file($_FILES['imagem']['tmp_name'], "uploads/" . $nome);
                $imagem = $nome;
            }

            Noticia::create([
                'titulo' => $_POST['titulo'],
                'conteudo' => $_POST['conteudo'],
                'imagem' => $imagem
            ]);

            header("Location: index.php");
        }

        require __DIR__ . '/../views/noticias/create.php';
    }

    public function view() {
        $noticia = Noticia::find($_GET['id']);
        require __DIR__ . '/../views/noticias/view.php';
    }

    public function edit() {
        $id = $_GET['id'];

        if ($_POST) {
            $imagem = $_POST['imagem_atual'];

            if (!empty($_FILES['imagem']['name'])) {
                $nome = time() . "_" . $_FILES['imagem']['name'];
                move_uploaded_file($_FILES['imagem']['tmp_name'], "uploads/" . $nome);
                $imagem = $nome;
            }

            Noticia::update($id, [
                'titulo' => $_POST['titulo'],
                'conteudo' => $_POST['conteudo'],
                'imagem' => $imagem
            ]);

            header("Location: index.php");
        }

        $noticia = Noticia::find($id);
        require __DIR__ . '/../views/noticias/edit.php';
    }

    public function delete() {
        Noticia::delete($_GET['id']);
        header("Location: index.php");
    }
}