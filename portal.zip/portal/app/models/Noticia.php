<?php
require_once __DIR__ . '/../../config/database.php';

class Noticia {

    public static function all() {
        $db = Database::connect();
        return $db->query("SELECT * FROM public.noticias ORDER BY data_publicacao DESC")
                  ->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function find($id) {
        $db = Database::connect();
        $stmt = $db->prepare("SELECT * FROM public.noticias WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function create($data) {
        $db = Database::connect();
        $stmt = $db->prepare("INSERT INTO public.noticias (titulo, conteudo, imagem) VALUES (?, ?, ?)");
        return $stmt->execute([$data['titulo'], $data['conteudo'], $data['imagem']]);
    }

    public static function update($id, $data) {
        $db = Database::connect();
        $stmt = $db->prepare("UPDATE public.noticias SET titulo=?, conteudo=?, imagem=? WHERE id=?");
        return $stmt->execute([$data['titulo'], $data['conteudo'], $data['imagem'], $id]);
    }

    public static function delete($id) {
        $db = Database::connect();
        $stmt = $db->prepare("DELETE FROM public.noticias WHERE id=?");
        return $stmt->execute([$id]);
    }
}