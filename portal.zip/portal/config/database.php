<?php
class Database {
    public static function connect() {
        return new PDO("pgsql:host=localhost;dbname=portal_educacao", "postgres", "1234");
    }
}